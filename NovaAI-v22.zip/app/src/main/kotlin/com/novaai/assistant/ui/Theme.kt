package com.novaai.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object NovaColors {
    val Navy = Color(0xFF07051A)
    val Navy2 = Color(0xFF14113A)
    val Card = Color(0xCC15122F)
    val Line = Color(0x558B5CFF)
    val Cyan = Color(0xFFB48CFF)      // accent (soft violet)
    val Blue = Color(0xFF6C4DFF)
    val Purple = Color(0xFF8B5CFF)
    val Pink = Color(0xFFE060FF)
    val Orange = Color(0xFFFFB547)    // selected tab, like LIA
    val Green = Color(0xFF2EE6B0)
    val TextDim = Color(0xFF9A93C0)
}

val NovaBg = Brush.verticalGradient(listOf(Color(0xFF1B1040), Color(0xFF0A0720), NovaColors.Navy), endY = 1800f)
val NovaGrad = Brush.linearGradient(listOf(NovaColors.Purple, NovaColors.Pink))

@Composable
fun NovaTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = NovaColors.Cyan, secondary = NovaColors.Purple,
        background = NovaColors.Navy, surface = NovaColors.Navy2,
        onBackground = Color.White, onSurface = Color.White
    ),
    content = content
)

@Composable
fun NovaCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val base = modifier.clip(RoundedCornerShape(16.dp)).background(NovaColors.Card)
        .border(1.dp, NovaColors.Line, RoundedCornerShape(16.dp))
    Box((if (onClick != null) base.clickable(onClick = onClick) else base).padding(14.dp)) { content() }
}

@Composable
fun Chip(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) = Box(
    modifier.clip(RoundedCornerShape(50)).background(NovaColors.Card)
        .border(1.dp, NovaColors.Line, RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
) { Text(text, fontSize = 13.sp) }
