package com.novaai.assistant.control

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.novaai.assistant.data.Store
import kotlinx.coroutines.delay

object DeviceActions {
    private fun launch(ctx: Context, i: Intent): Boolean =
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess

    fun webSearch(ctx: Context, q: String) =
        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))

    fun openYouTube(ctx: Context) =
        openPackage(ctx, "com.google.android.youtube") || launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))

    fun openMaps(ctx: Context) =
        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))

    private fun openPackage(ctx: Context, pkg: String): Boolean =
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { launch(ctx, it) } ?: false

    fun openAppByName(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(q, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name.lowercase())
        } ?: return false
        return openPackage(ctx, hit.activityInfo.packageName)
    }

    fun setTimer(ctx: Context, seconds: Int, label: String) =
        launch(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))

    fun setAlarmFromText(ctx: Context, raw: String): String {
        val t = raw.lowercase()
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|a\\.m|p\\.m)?").find(t)
        if (m == null) {
            launch(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))
            return "Tell me a time, like 7:30 am"
        }
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = m.groupValues[3]
        if (ap.startsWith("p") && h < 12) h += 12
        if (ap.startsWith("a") && h == 12) h = 0
        if (ap.isEmpty() && h in 1..11 && (t.contains("বিকাল") || t.contains("সন্ধ্যা") || t.contains("রাত"))) h += 12
        if (h > 23 || min > 59) return "That time doesn't look right"
        val ok = launch(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Nova").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        val hh = if (h % 12 == 0) 12 else h % 12
        return if (ok) "অ্যালার্ম সেট করলাম, %d:%02d %s, %s ভাই".format(hh, min, if (h >= 12) "PM" else "AM", Store.name) else "No clock app found"
    }

    /** Android only lets an app stop *background* processes, so this reports the measured change. */
    suspend fun clearBackground(ctx: Context): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        fun free(): Long = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        val before = free()
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(q, 0).map { it.activityInfo.packageName }.distinct()
            .filter { it != ctx.packageName }
            .forEach { runCatching { am.killBackgroundProcesses(it) } }
        delay(500)
        val kb = ((free() - before) / 1024).coerceAtLeast(0)
        return if (kb > 0) "Successfully cleared $kb kb memory" else "Memory is already clean"
    }
}
