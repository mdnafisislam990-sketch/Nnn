package com.novaai.assistant.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.novaai.assistant.data.Store
import java.util.Locale

/** Speech-to-text. Must be used on the main thread. */
class Stt(private val ctx: Context) {
    private var rec: SpeechRecognizer? = null

    fun start(onText: (String) -> Unit, onFail: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail("Speech recognition isn't available on this phone"); return
        }
        stop()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(e: Int) {
                onFail(
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Allow the microphone for Nova"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Check your internet"
                        else -> "Voice error ($e)"
                    }
                )
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) onFail("I didn't catch that") else onText(t)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Store.str("lang", "bn-BD"))
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        r.startListening(i)
    }

    fun stop() {
        rec?.let { runCatching { it.cancel() }; runCatching { it.destroy() } }
        rec = null
    }
}

object Tts {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var onDone: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    private fun finish() {
        val d = onDone
        onDone = null
        if (d != null) main.post { d() }
    }

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { finish() }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { finish() }
        override fun onError(utteranceId: String?, errorCode: Int) { finish() }
    }

    @Volatile private var gen = 0
    @Volatile private var track: AudioTrack? = null

    private val pool = java.util.concurrent.Executors.newFixedThreadPool(2) { r -> Thread(r).also { it.isDaemon = true } }

    private fun synth(t: String): ByteArray? {
        repeat(2) {
            val p = (if (Store.str("k_eleven").isNotBlank()) runCatching { com.novaai.assistant.ai.LlmClient.elevenPcm(t) }.getOrNull() else null)
                ?: (if (Store.str("k_gemini").isNotBlank()) runCatching { com.novaai.assistant.ai.LlmClient.speechPcm(t) }.getOrNull() else null)
            if (p != null && p.isNotEmpty()) return p
        }
        return null
    }

    /** Splits into short sentences so the first one can start playing while the rest are still being made. */
    private fun chunks(t: String): List<String> {
        val parts = Regex("(?<=[\u0964.!?\\n])\\s+").split(t).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        for (p in parts) {
            if (out.isNotEmpty() && out.last().length < 25) out[out.size - 1] = out.last() + " " + p else out.add(p)
        }
        while (out.size > 4) { val l = out.removeAt(out.size - 1); out[out.size - 1] = out.last() + " " + l }
        return out.ifEmpty { listOf(t) }
    }

    private class Item(val fut: java.util.concurrent.Future<ByteArray?>?)

    /** Speech that starts as soon as the first sentence is added; more sentences can be added while it talks. */
    class Sink internal constructor(private val my: Int, private val ctx: Context) {
        private val q = java.util.concurrent.LinkedBlockingQueue<Item>()
        private val all = StringBuilder()

        fun add(sentence: String) {
            val t = sentence.trim()
            if (t.isEmpty() || my != gen) return
            all.append(t).append(' ')
            q.offer(Item(pool.submit(java.util.concurrent.Callable { synth(t.take(400)) })))
        }

        fun end() { q.offer(Item(null)) }

        /** Throw this speech away (used when the answer turns out to be a phone command). */
        fun abort() { if (gen == my) gen++; q.offer(Item(null)) }

        internal fun run() {
            Thread {
                var tr: AudioTrack? = null
                var frames = 0L
                try {
                    while (true) {
                        val it = q.take()
                        val f = it.fut ?: break
                        val pcm = try { f.get() } catch (e: Exception) { null }
                        if (my != gen) return@Thread
                        if (pcm == null || pcm.isEmpty()) continue
                        if (tr == null) { tr = newTrack(); track = tr; tr.play() }
                        tr.write(pcm, 0, pcm.size)
                        frames += pcm.size / 2
                    }
                    if (my != gen) return@Thread
                    if (tr == null) {
                        val t = all.toString().trim()
                        if (t.isEmpty()) finish() else main.post { if (my == gen) deviceSpeak(ctx, t) }
                        return@Thread
                    }
                    val limit = System.currentTimeMillis() + frames / 24 + 1500
                    while (my == gen && tr.playbackHeadPosition < frames && System.currentTimeMillis() < limit) Thread.sleep(30)
                } catch (e: Exception) {
                } finally {
                    tr?.let { runCatching { it.stop() }; runCatching { it.release() }; if (track === it) track = null }
                }
                if (my == gen) finish()
            }.start()
        }
    }

    fun begin(ctx: Context, done: (() -> Unit)? = null): Sink {
        onDone = done
        val s = Sink(++gen, ctx.applicationContext)
        s.run()
        return s
    }

    /** onDone runs on the main thread after speech ends (or fails). Uses the Gemini/ElevenLabs voice if you have a key, else the phone voice. */
    fun speak(ctx: Context, text: String, done: (() -> Unit)? = null) {
        val t = text.take(600)
        if (Store.str("k_gemini").isBlank() && Store.str("k_eleven").isBlank()) {
            onDone = done
            val my = ++gen
            main.post { if (my == gen) deviceSpeak(ctx, t) }
            return
        }
        val s = begin(ctx, done)
        chunks(t).forEach { s.add(it) }
        s.end()
    }

    private fun newTrack(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 9600))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun deviceSpeak(ctx: Context, t: String) {
        if (tts == null) {
            pending = t
            tts = TextToSpeech(ctx.applicationContext) { s ->
                ready = s == TextToSpeech.SUCCESS
                val p = pending
                pending = null
                if (ready) {
                    tts?.setOnUtteranceProgressListener(progress)
                    if (p != null) say(p)
                } else finish()
            }
        } else if (ready) say(t) else pending = t
    }

    private fun say(t: String) {
        val e = tts ?: return
        val bn = t.any { it in '\u0980'..'\u09FF' }
        val r = e.setLanguage(if (bn) Locale("bn", "BD") else Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) e.setLanguage(Locale.getDefault())
        e.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nova")
    }

    fun stop() {
        onDone = null
        gen++
        runCatching { track?.pause(); track?.flush() }
        tts?.stop()
    }
}

/**
 * Microphone that stays on. It restarts itself after every phrase, every silence and every error,
 * rebuilds the recognizer when it hangs, and keeps the system "beep" quiet. Main thread only.
 */
class LiveListener(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onHearing: (Boolean) -> Unit,
    private val onFatal: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var running = false
    private var paused = false
    private var fails = 0
    private var netFails = 0
    private var lang = Store.str("lang", "bn-BD")
    private val restart = Runnable { begin() }
    private val watchdog = Runnable { rebuild(300) }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { fails = 0 }
        override fun onBeginningOfSpeech() {
            onHearing(true)
            main.removeCallbacks(watchdog); main.postDelayed(watchdog, 45000)
        }
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { onHearing(false) }
        override fun onPartialResults(b: Bundle?) {}
        override fun onEvent(t: Int, b: Bundle?) {}

        override fun onResults(b: Bundle?) {
            main.removeCallbacks(watchdog)
            onHearing(false)
            fails = 0
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
            if (!t.isNullOrEmpty()) { netFails = 0; onText(t) }
            if (running && !paused) schedule(200)
        }

        override fun onError(e: Int) {
            main.removeCallbacks(watchdog)
            onHearing(false)
            if (!running || paused) return
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> schedule(150)
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> onFatal("Allow the microphone for Nova")
                12, 13 -> { lang = "en-US"; rebuild(500) }                  // language not supported / unavailable
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> {
                    netFails++
                    if (netFails >= 6) onFatal("Offline speech pack missing. Download Bangla and English in Google settings, Offline speech recognition.")
                    else schedule((1000L * netFails).coerceAtMost(6000L))
                }
                else -> { fails++; rebuild((600L + 500L * fails).coerceAtMost(5000L)) }   // busy, client, audio, disconnected
            }
        }
    }

    fun start() {
        if (running) return
        running = true; paused = false; fails = 0
        lang = Store.str("lang", "bn-BD")
        quietBeep(true)
        schedule(0)
    }

    fun stop() {
        running = false
        main.removeCallbacksAndMessages(null)
        destroy()
        quietBeep(false)
        onHearing(false)
    }

    /** Stop hearing while Nova talks or works, so it never listens to itself. */
    fun pause() {
        paused = true
        main.removeCallbacks(restart); main.removeCallbacks(watchdog)
        runCatching { rec?.cancel() }
        onHearing(false)
    }

    fun resume() {
        if (!running) return
        paused = false
        schedule(250)
    }

    private fun schedule(ms: Long) {
        main.removeCallbacks(restart)
        main.postDelayed(restart, ms)
    }

    private fun destroy() {
        rec?.let { runCatching { it.cancel() }; runCatching { it.destroy() } }
        rec = null
    }

    private fun rebuild(ms: Long) {
        destroy()
        if (running && !paused) schedule(ms)
    }

    private fun begin() {
        if (!running || paused) return
        val onDevice = Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)
        if (!onDevice && !SpeechRecognizer.isRecognitionAvailable(ctx)) { onFatal("Speech recognition isn't available on this phone"); return }
        val r = rec ?: (if (onDevice) SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx) else SpeechRecognizer.createSpeechRecognizer(ctx))
            .also { it.setRecognitionListener(listener); rec = it }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        try { r.startListening(i) } catch (e: Exception) { rebuild(800); return }
        main.removeCallbacks(watchdog); main.postDelayed(watchdog, 25000)
    }

    private fun quietBeep(on: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val dir = if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        val streams = ArrayList<Int>()
        streams.add(AudioManager.STREAM_SYSTEM)
        if (Store.bool("mute_notif")) streams.add(AudioManager.STREAM_NOTIFICATION)
        for (s in streams) runCatching { am.adjustStreamVolume(s, dir, 0) }
    }
}
